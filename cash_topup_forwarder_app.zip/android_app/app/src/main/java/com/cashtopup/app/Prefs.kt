package com.cashtopup.app

import android.content.Context
import org.json.JSONArray

object Prefs {
    private const val FILE = "cash_topup_prefs"
    private const val KEY_SERVER_URL = "server_url"
    private const val KEY_API_KEY = "api_key"
    private const val KEY_LOG = "recent_log"
    private const val MAX_LOG_ITEMS = 30

    private fun prefs(context: Context) =
        context.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    fun getServerUrl(context: Context): String =
        prefs(context).getString(KEY_SERVER_URL, "") ?: ""

    fun setServerUrl(context: Context, url: String) {
        prefs(context).edit().putString(KEY_SERVER_URL, url.trim()).apply()
    }

    fun getApiKey(context: Context): String =
        prefs(context).getString(KEY_API_KEY, "") ?: ""

    fun setApiKey(context: Context, key: String) {
        prefs(context).edit().putString(KEY_API_KEY, key.trim()).apply()
    }

    fun isConfigured(context: Context): Boolean =
        getServerUrl(context).isNotBlank() && getApiKey(context).isNotBlank()

    /** Adds a line to the small rolling local log so the admin can see recent activity in the app. */
    fun addLogLine(context: Context, line: String) {
        val old = getLogArray(context)
        val newArr = JSONArray()
        newArr.put(line)
        for (i in 0 until old.length()) {
            if (newArr.length() >= MAX_LOG_ITEMS) break
            newArr.put(old.optString(i))
        }
        prefs(context).edit().putString(KEY_LOG, newArr.toString()).apply()
    }

    fun getLogText(context: Context): String {
        val arr = getLogArray(context)
        val sb = StringBuilder()
        for (i in 0 until arr.length()) {
            sb.append(arr.optString(i))
            sb.append("\n\n")
        }
        return if (sb.isEmpty()) "لا يوجد نشاط بعد" else sb.toString()
    }

    private fun getLogArray(context: Context): JSONArray {
        val raw = prefs(context).getString(KEY_LOG, "[]") ?: "[]"
        return try {
            JSONArray(raw)
        } catch (e: Exception) {
            JSONArray()
        }
    }
}
