package com.cashtopup.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var serverUrlInput: EditText
    private lateinit var apiKeyInput: EditText
    private lateinit var statusText: TextView
    private lateinit var logText: TextView

    private val requiredPermissions = mutableListOf(
        Manifest.permission.RECEIVE_SMS,
        Manifest.permission.READ_SMS
    ).apply {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            add(Manifest.permission.POST_NOTIFICATIONS)
        }
    }.toTypedArray()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        serverUrlInput = findViewById(R.id.serverUrlInput)
        apiKeyInput = findViewById(R.id.apiKeyInput)
        statusText = findViewById(R.id.statusText)
        logText = findViewById(R.id.logText)

        serverUrlInput.setText(Prefs.getServerUrl(this))
        apiKeyInput.setText(Prefs.getApiKey(this))

        findViewById<Button>(R.id.saveButton).setOnClickListener {
            Prefs.setServerUrl(this, serverUrlInput.text.toString())
            Prefs.setApiKey(this, apiKeyInput.text.toString())
            Toast.makeText(this, "تم الحفظ", Toast.LENGTH_SHORT).show()
            updateStatus()
        }

        findViewById<Button>(R.id.grantPermissionsButton).setOnClickListener {
            ActivityCompat.requestPermissions(this, requiredPermissions, 100)
        }

        findViewById<Button>(R.id.batteryButton).setOnClickListener {
            requestIgnoreBatteryOptimizations()
        }

        findViewById<Button>(R.id.startServiceButton).setOnClickListener {
            startForwarderService()
            Toast.makeText(this, "تم تشغيل الخدمة", Toast.LENGTH_SHORT).show()
            updateStatus()
        }

        findViewById<Button>(R.id.refreshLogButton).setOnClickListener {
            refreshLog()
        }

        updateStatus()
        refreshLog()
    }

    override fun onResume() {
        super.onResume()
        updateStatus()
        refreshLog()
    }

    private fun updateStatus() {
        val hasSmsPermission = ContextCompat.checkSelfPermission(
            this, Manifest.permission.RECEIVE_SMS
        ) == PackageManager.PERMISSION_GRANTED

        val sb = StringBuilder()
        sb.append(if (hasSmsPermission) "✅ صلاحية قراءة الرسائل: متاحة\n" else "❌ صلاحية قراءة الرسائل: غير متاحة\n")
        sb.append(if (Prefs.isConfigured(this)) "✅ إعدادات السيرفر: متظبطة\n" else "❌ إعدادات السيرفر: لسه ناقصة\n")
        statusText.text = sb.toString()
    }

    private fun refreshLog() {
        logText.text = Prefs.getLogText(this)
    }

    private fun startForwarderService() {
        val intent = Intent(this, ForwarderService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(intent)
        } else {
            startService(intent)
        }
    }

    private fun requestIgnoreBatteryOptimizations() {
        val pm = getSystemService(POWER_SERVICE) as PowerManager
        if (!pm.isIgnoringBatteryOptimizations(packageName)) {
            val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
            intent.data = Uri.parse("package:$packageName")
            startActivity(intent)
        } else {
            Toast.makeText(this, "التطبيق مستثنى بالفعل من توفير البطارية", Toast.LENGTH_SHORT).show()
        }
    }
}
