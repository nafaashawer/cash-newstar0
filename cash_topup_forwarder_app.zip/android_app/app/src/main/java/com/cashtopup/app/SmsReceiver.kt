package com.cashtopup.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Telephony
import android.telephony.SmsMessage

class SmsReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Telephony.Sms.Intents.SMS_RECEIVED_ACTION) return
        if (!Prefs.isConfigured(context)) {
            Prefs.addLogLine(context, "وصلت رسالة لكن التطبيق مش متظبط لسه (رابط السيرفر / المفتاح السري)")
            return
        }

        val messagesBySender = LinkedHashMap<String, StringBuilder>()

        // رسالة الكاش أحياناً بتوصل كأكثر من جزء (multipart)، فبنجمعها كلها لنفس المرسل
        val pdus = Telephony.Sms.Intents.getMessagesFromIntent(intent)
        for (smsMessage: SmsMessage in pdus) {
            val sender = smsMessage.originatingAddress ?: "unknown"
            val body = smsMessage.messageBody ?: ""
            val builder = messagesBySender.getOrPut(sender) { StringBuilder() }
            builder.append(body)
        }

        for ((sender, bodyBuilder) in messagesBySender) {
            val fullMessage = bodyBuilder.toString()
            val service = detectService(sender, fullMessage)
            NetworkHelper.forwardSms(context, service, sender, fullMessage)
        }
    }

    /** تخمين بسيط لاسم خدمة الكاش بناءً على المرسل أو محتوى الرسالة، السيرفر برضه بيتحقق ويحلل النص بنفسه. */
    private fun detectService(sender: String, message: String): String {
        val text = (sender + " " + message).lowercase()
        return when {
            text.contains("vodafone") || text.contains("فودافون") -> "vodafone"
            text.contains("etisalat") || text.contains("اتصالات") -> "etisalat"
            text.contains("orange") || text.contains("أورانج") || text.contains("اورانج") -> "orange"
            text.contains("we ") || text.contains(" we") || text.contains("المصرية للاتصالات") -> "we"
            else -> "unknown"
        }
    }
}
