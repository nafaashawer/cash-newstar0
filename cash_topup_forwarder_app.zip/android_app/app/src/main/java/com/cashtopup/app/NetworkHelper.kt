package com.cashtopup.app

import android.content.Context
import android.util.Log
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

object NetworkHelper {
    private const val TAG = "CashTopUpForwarder"

    /** Sends the SMS details to the server API on a background thread. Never call from the main thread. */
    fun forwardSms(context: Context, service: String, sender: String, message: String) {
        Thread {
            val serverUrl = Prefs.getServerUrl(context)
            val apiKey = Prefs.getApiKey(context)

            if (serverUrl.isBlank() || apiKey.isBlank()) {
                Prefs.addLogLine(context, "خطأ: لسه ما ضبطتش رابط السيرفر أو المفتاح السري في إعدادات التطبيق")
                return@Thread
            }

            var connection: HttpURLConnection? = null
            try {
                val url = URL(serverUrl)
                connection = url.openConnection() as HttpURLConnection
                connection.requestMethod = "POST"
                connection.doOutput = true
                connection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8")
                connection.connectTimeout = 15000
                connection.readTimeout = 15000

                val postData = "api_key=" + URLEncoder.encode(apiKey, "UTF-8") +
                        "&service=" + URLEncoder.encode(service, "UTF-8") +
                        "&sender=" + URLEncoder.encode(sender, "UTF-8") +
                        "&message=" + URLEncoder.encode(message, "UTF-8")

                OutputStreamWriter(connection.outputStream, "UTF-8").use { writer ->
                    writer.write(postData)
                    writer.flush()
                }

                val responseCode = connection.responseCode
                val stream = if (responseCode in 200..299) connection.inputStream else connection.errorStream
                val responseText = BufferedReader(InputStreamReader(stream, "UTF-8")).use { it.readText() }

                Log.d(TAG, "Response ($responseCode): $responseText")
                Prefs.addLogLine(
                    context,
                    "من: $sender\nالخدمة: $service\nنتيجة السيرفر ($responseCode): $responseText"
                )
            } catch (e: Exception) {
                Log.e(TAG, "Failed to forward SMS", e)
                Prefs.addLogLine(context, "فشل الاتصال بالسيرفر: ${e.message}\nالرسالة من: $sender")
            } finally {
                connection?.disconnect()
            }
        }.start()
    }
}
